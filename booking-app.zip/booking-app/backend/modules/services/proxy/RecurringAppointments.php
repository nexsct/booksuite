<?php
namespace Bookly\Backend\Modules\Services\Proxy;

use Bookly\Lib;

/**
 * Class RecurringAppointments
 * @package Bookly\Backend\Modules\Services\Proxy
 *
 * @method static void renderSubForm( array $service ) Render repeat sub form.
 */
abstract class RecurringAppointments extends Lib\Base\Proxy
{

}