<?php
namespace Bookly\Backend\Modules\Appointments\Proxy;

use Bookly\Lib;

/**
 * Deprecated, will be deleted in Bookly 17.9
 */
abstract class Locations extends Lib\Base\Proxy
{

}