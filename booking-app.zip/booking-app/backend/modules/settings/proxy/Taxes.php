<?php
namespace Bookly\Backend\Modules\Settings\Proxy;

use Bookly\Lib;

/**
 * Class Taxes
 * @package Bookly\Backend\Modules\Settings\Proxy
 *
 * @method static array renderPayments() Render "Deposit options" in "Payments" tab.
 */
abstract class Taxes extends Lib\Base\Proxy
{

}