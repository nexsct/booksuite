<?php
namespace Bookly\Backend\Components\Dialogs\Customer\Proxy;

use Bookly\Lib;

/**
 * @since Bookly 16.2
 * @deprecated To be removed in the future.
 * Proxy file was moved
 */
abstract class Pro extends Lib\Base\Proxy
{

}