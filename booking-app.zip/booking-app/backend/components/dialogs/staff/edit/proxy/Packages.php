<?php
namespace Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy;

use Bookly\Lib;

/**
 * Class Packages
 *
 * @package Bookly\Backend\Components\Dialogs\Staff\Edit\Proxy
 *
 * @method static void renderStaffServicesTip()
 */
abstract class Packages extends Lib\Base\Proxy
{

}