<?php if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly ?>
<div class="col-12 col-sm-auto">
    <button type="button" class="btn btn-default w-100 mb-3 bookly-js-table-settings" data-location="<?php echo $location ?>" data-table-name="<?php echo $table_name ?>" data-setting-name="<?php echo $setting_name ?>"><i class="far fa-fw fa-eye"></i></button>
</div>